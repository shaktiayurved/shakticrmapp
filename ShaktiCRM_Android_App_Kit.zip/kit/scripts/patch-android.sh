#!/usr/bin/env bash
# Runs in CI after `npx cap add android`: permissions, Firebase file, ring sound, app icon.
set -euo pipefail
A=android/app/src/main
[ -n "${GOOGLE_SERVICES_JSON:-}" ] || { echo "::error::Secret GOOGLE_SERVICES_JSON is missing (Firebase file). See README."; exit 1; }
printf '%s' "$GOOGLE_SERVICES_JSON" > android/app/google-services.json

python3 - <<'PY'
p='android/app/src/main/AndroidManifest.xml'
s=open(p,encoding='utf-8').read()
perms=['ACCESS_NETWORK_STATE','POST_NOTIFICATIONS','RECORD_AUDIO','MODIFY_AUDIO_SETTINGS','VIBRATE','WAKE_LOCK']
add=''.join('\n    <uses-permission android:name="android.permission.%s" />'%x for x in perms if 'android.permission.%s"'%x not in s)
s=s.replace('<application',add.lstrip('\n')+'\n\n    <application',1) if add else s
open(p,'w',encoding='utf-8').write(s)
PY

mkdir -p $A/res/raw && cp resources/ring.wav $A/res/raw/ring.wav

# icons (legacy PNG on every Android version; remove the placeholder adaptive icon)
rm -rf $A/res/mipmap-anydpi-v26
for d in "mdpi 48" "hdpi 72" "xhdpi 96" "xxhdpi 144" "xxxhdpi 192"; do
  set -- $d; mkdir -p $A/res/mipmap-$1
  convert resources/icon.png -resize $2x$2 $A/res/mipmap-$1/ic_launcher.png
  cp $A/res/mipmap-$1/ic_launcher.png $A/res/mipmap-$1/ic_launcher_round.png
  cp $A/res/mipmap-$1/ic_launcher.png $A/res/mipmap-$1/ic_launcher_foreground.png
done
echo "patched OK"; grep -n "uses-permission" $A/AndroidManifest.xml
